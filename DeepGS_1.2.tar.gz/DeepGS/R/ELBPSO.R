#ELBPSO initialization function
ELBPSO_initialized<-function(weight_dimension,weight_min,weight_max,rate_min,rate_max,paticle_number,para_deliver,IW,AF1,AF2){
  Global<-rep(NA,2*weight_dimension+1)
  Weight<-matrix(runif(paticle_number*weight_dimension,weight_min,weight_max),nrow=paticle_number,ncol=weight_dimension)
  Rate<-matrix(runif(paticle_number*weight_dimension,rate_min,rate_max),nrow=paticle_number,ncol=weight_dimension)
  Fitness<-apply(Weight,1,function(ccc){return(ELBPSO_fitness(ccc, para_deliver))})
  Global<-cbind(Weight,Rate,Fitness)[which(Fitness==max(Fitness))[1],]
  return(rbind(cbind(Weight,Rate,Fitness),Global))
}
#ELBPSO global update function 
ELBPSO_global_update<-function(Paremeter_matrix,weight_dimension,paticle_number){
  Fitness<-Paremeter_matrix[-(paticle_number+1),2*weight_dimension+1]
  return(rbind(Paremeter_matrix[-(paticle_number+1),],Paremeter_matrix[which(Fitness==max(Fitness))[1],]))
}
#ELBPSO optimized function
ELBPSO_optimized<-function(Paremeter_matrix,weight_dimension,weight_min,weight_max,rate_min,rate_max,paticle_number,para_deliver,IW,AF1,AF2){
  Weight<-Paremeter_matrix[-(paticle_number+1),1:weight_dimension]
  Rate<-Paremeter_matrix[-(paticle_number+1),(weight_dimension+1):(2*weight_dimension)]
  Fitness<-Paremeter_matrix[-(paticle_number+1),2*weight_dimension+1]
  for(i in 1:paticle_number){
    New_weight<-Weight[i,]+Rate[i,]
    for(j in 1:weight_dimension){
      if(New_weight[j]>weight_max || New_weight[j]<weight_min || is.na(New_weight[j])){
        New_weight[j]<-runif(1,weight_min,weight_max)     }
    }
    if(ELBPSO_fitness(New_weight, para_deliver)>ELBPSO_fitness(Weight[i,], para_deliver)){
      Weight[i,]<-New_weight
      Rate[i,]<-IW*(Rate[i,]+AF1*runif(1,0,1)*Rate[i,]+AF2*runif(1,0,1)*(Paremeter_matrix[paticle_number+1,1:length(Weight[i,])]-Weight[i,]))
      for(k in 1:weight_dimension){
        if(Rate[i,k]>rate_max || Rate[i,k]<rate_min || is.na(Rate[i,k])){
          Rate[i,k]=runif(1,rate_min,rate_max)     }
      }
      Fitness[i]<-ELBPSO_fitness(New_weight, para_deliver)
    } else{
      Rate[i,]<-IW*(Rate[i,]+AF2*runif(1,0,1)*(Paremeter_matrix[paticle_number+1,1:length(Weight[i,])]-Weight[i,]))
      for(k in 1:weight_dimension){
        if(Rate[i,k]>rate_max || Rate[i,k]<rate_min || is.na(Rate[i,k])){
          Rate[i,k]=runif(1,rate_min,rate_max)     }
      }
    }
  }
  Global<-rep(NA,2*weight_dimension+1)
  Global_update<-ELBPSO_global_update(rbind(cbind(Weight,Rate,Fitness),Global),weight_dimension,paticle_number)
  return(Global_update)
}
#ELBPSO fitness function
ELBPSO_fitness<-function(weight, para_deliver){
  weight_predict <- apply(t(t(para_deliver$predict_models[para_deliver$train_num,])*weight),1,sum)/sum(weight) 
  whole_meanNDCG <- meanNDCG(realScores = para_deliver$indepedent_pheno[para_deliver$train_num],
                              predScores = weight_predict, topAlpha = 1)
  return(whole_meanNDCG)
}


##################################################
#'@title Ensemble Learning Based on Particle Swarm Optimization (ELBPSO) 
#'@description The algorithm combines the predicted phenotypic values from different GS models and return the best weights between these models.
#'@param  rep_times ELBPSO repeat times default is 100.
#'@param  interation_times Each ELBPSO optimized iteration times.
#'@param  weight_dimension Weight dimension.
#'@param  weight_min Minimum weight.
#'@param  weight_max Maximum weight.
#'@param  rate_min Minimum update rate.
#'@param  rate_max Maximum update rate.
#'@param  paticle_number Patricle number.
#'@param  pred_matrix The first column represents the real values the other columns represent the predictd values of other GS models.
#'@param  IW Inertia weight default is 1.
#'@param  AF1 Accelerated factor 1 default is 2.
#'@param  AF2 Accelerated factor 2 default is 2.
#'@export
#' @examples
#' ## Not run
#' # example for rrBLUP model
#' # library(DeepGS)
#' # library(rrBLUP)
#' # data("wheat_example")
#' # Markers <- wheat_example$Markers
#' # y <- wheat_example$y
#' # cvSampleList <- cvSampleIndex(length(y),10,1)
#' ## select one fold
#' # cvIdx <- 1
#' # trainIdx <- cvSampleList[[cvIdx]]$trainIdx
#' # testIdx <- cvSampleList[[cvIdx]]$testIdx
#' # trainMat = Markers[trainIdx,]
#' # trainPheno = y[trainIdx]
#' # testMat = Markers[testIdx,]
#' # testPheno = y[testIdx]
#' # rrBLUP_obj <-mixed.solve(trainPheno, Z=trainMat, K=NULL, SE = FALSE, return.Hinv=FALSE)
#' # rrBLUP_pred <-  testMat %*% rrBLUP_obj$u + as.numeric(rrBLUP_obj$beta )
#' ## End not run 
#' # calculating the weight of different training model by using their predict socres
#' test_datapath <- system.file("exdata", "test_ELBPSO.RData",
#'                              package = "DeepGS")
#' load(test_datapath)
#' weight <- ELBPSO(rep_times = 100,interation_times = 25,weight_dimension = 2,
#'                  weight_min = 0,weight_max=1,rate_min = -0.01,rate_max = 0.01,
#'                  paticle_number = 10, pred_matrix = train_predMat,IW = 1,
#'                  AF1 = 2, AF2 = 2)
#' 
#' new_pre <- (test_predMat %*% weight)/sum(weight)

ELBPSO<-function(rep_times = 100,interation_times,weight_dimension,weight_min,weight_max,rate_min,rate_max,
                 paticle_number,pred_matrix,IW = 1, AF1 = 2, AF2 = 2){
  
  para_deliver <- list()
  para_deliver$predict_models <- pred_matrix[,2:ncol(pred_matrix)]
  para_deliver$indepedent_pheno <- pred_matrix[,1]
  para_deliver$train_num <- c(1:length(pred_matrix[,1]))
  best_weight_rep <- matrix(,ncol(pred_matrix)-1,rep_times)
  IW <- IW
  AF1 <- AF1
  AF2 <- AF2
  pb <- txtProgressBar(min = 1,max = rep_times,style = 3)
  for(rep in 1:rep_times){
    Paremeter_matrix<-ELBPSO_initialized(weight_dimension,weight_min,weight_max,rate_min,rate_max,paticle_number,para_deliver,IW,AF1,AF2)
    Weight<-matrix(0,nrow=2,ncol=interation_times)
    for(j in 1:interation_times){
      Weight[1,j]<-j
      Paremeter_matrix<-ELBPSO_optimized(Paremeter_matrix,weight_dimension,weight_min,weight_max,rate_min,rate_max,paticle_number,para_deliver,IW,AF1,AF2)
      Global<-Paremeter_matrix[(paticle_number+1),1:weight_dimension]
      Weight[2,j]<-ELBPSO_fitness(Global, para_deliver)
      if(ELBPSO_fitness(Global, para_deliver)>0.999) break
      
    }
    best_weight_rep[,rep] <- Global
    setTxtProgressBar(pb, rep)
   
  }
  close(pb)
  weight<- apply(best_weight_rep,1, mean)
  return(weight)
}



