NDCGEvaluation <- function( realScores, predScores, topK = 10){
  
  if( length(realScores) != length(predScores) ){
    stop("Error: different length between realScores and predScores")
  }
  if( length(realScores) < topK ) {
    stop("Error: too large topK")
  }
  
  scoreMat <- cbind(realScores,predScores)
  scoreMatSortbyPred <- scoreMat[order(scoreMat[,2],decreasing = TRUE),]
  scoreMatSortByReal <- scoreMat[order(scoreMat[,1],decreasing = TRUE),]
  
  DCG <- rep(0, topK)
  IDCG <- rep(0, topK)
  for(idx in 1:topK){
    DCG[idx] <-  scoreMatSortbyPred[idx,1]/log(idx+1,2)
    IDCG[idx] <- scoreMatSortByReal[idx,1]/log(idx+1,2)
  }
  
  NDCG <- sum(DCG)/sum(IDCG) 
  names(NDCG) <- paste0("NDCG","_top",topK)
  return(NDCG)
}


########################################################################
#' @title Calculate mean Normalied Doscounted Cumulative Gain
#' @description  This function calculates the mean normalied doscounted cumulative gain(meanNDCG) value for 
#' evaluting the prediction performance of a genomic selection  prediction model in selecting top k individuals with high breeding value.
#' @param realScores  A numeric vector is the real breeding values of the validation individual for a trait.
#' @param predScores  A numeric vector or matrix is the prediction breeding value predicted by genomic selection model of the individuals.
#' @param topK  A numeric vector is the number of excellent individuals.
#' 
#' @author Chuang Ma, Zhixu Qiu, Qian Cheng, Wenlong Ma
#' @export
#' @examples
#' ## Not run
#' refer_value <- runif(100)
#' pred_value <- sin(refer_value) + cos(refer_value)
#' meanNDCG(realScores = refer_value,predScores = pred_value, topK = 10)
#' ## End (Not run)
meanNDCG <- function( realScores, predScores, topK = 10 ){
  resVec <- rep(0, topK )
  for( idx in 1:topK ){
    resVec[idx] <- NDCGEvaluation( realScores, predScores, topK = idx )
  }
  meanNDCG_scores <- mean(resVec)
  names(meanNDCG_scores) <- paste0("meanNDCG","_top",topK)
  return (meanNDCG_scores)
}
