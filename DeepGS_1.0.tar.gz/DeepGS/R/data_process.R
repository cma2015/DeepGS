########################## load example data ###########################
#' @name wheat_example
#' @title Run a examples for an in-development function.
#' @description 
#' A list,involve:
#' \itemize{
#' \item{Marker:} {A matrix(599 * 1225), each row represent 1225 markers information for one individuals.}
#' \item{y:} {The real phenotype value for each individual.}
#' }
#' @docType data
#' @usage data(wheat_example)
NULL


#' @title predict_GSModel
#' @description Predict trait values using trained deep learning genomic selection prediction model.
#' @author Chuang Ma  , Qian Cheng, Zhixu Qiu,Wenlong Ma
#' @param GSModel Trained prediction model obtained from the DeepGSModel function.
#' @param testMat  A genotype matrix(T * M; T individuals, M markers)
#' @param imageSize (String)this gives a "i * j" image format that the (M x1)markers informations of each individual will be encoded.
#' @export
predict_GSModel <- function(GSModel,testMat,imageSize){
  imageSize <- as.numeric(unlist(strsplit(imageSize,"\\*")))
  testMat <- t(testMat)
  if(imageSize[1]*imageSize[2] > nrow(testMat)){
    testMat <- rbind(testMat,matrix(0,imageSize[1]*imageSize[2] - nrow(testMat),ncol = ncol(testMat)))
    # print("the image size exceeds the original snp number, 0 will be polished the lack part")
  }else if(imageSize[1]*imageSize[2] < nrow(testMat)){
    testMat <- testMat[1:(imageSize[1]*imageSize[2]),] 
    # print("the image size is less than the original snp number, the last snp(s) will be descaled")
  }
 
  dim(testMat) <-  c(imageSize[1], imageSize[2],1,ncol(testMat))
  predict(GSModel,testMat)
}



# ######################### get system time for seed and then generate random index ###########
# title Generate Random Seed
# description This funcation is appplied for generating random seed with current system time
# return  
# (numeric) A random seed 
# author Chuang Ma  , Qian Cheng , Zhixu Qiu ,Wenlong Ma

randomSeed <- function() {
  curtime <- format(Sys.time(), "%H:%M:%OS4")
  XXX <- unlist(strsplit(curtime, ":"))
  curtimeidx <- (as.numeric(XXX[1])*3600 + as.numeric(XXX[2])*60 + as.numeric(XXX[3]))*10000
  curtimeidx
}


########################generate train idx and test idx ##########################
#' @title Generate Sample Indices for Training Sets and Testing Sets
#' @description  This function generates indices for samples in training and testing sets for performing the N-fold cross validation experiment.
#' @param sampleNum  The number of samples needed to be partitioned into training and testing sets.
#' @param cross  The fold of cross validation.
#' @param seed  An integer used as the seed for data partition. The default value is 1.
#' @param randomSeed  Logical variable, default FALSE.
#' @return 
#' A list and each element including $trainIdx $testIdx and $cvIdx
#' 
#' $trainIdx  The index of training samples.
#' 
#' $testIdx   The index of testing samples.
#' 
#' $cvIdx     The cross validation index.
#' @author Chuang Ma, Zhixu Qiu, Qian Cheng, Wenlong Ma
#' @export
#' @examples
#' ## Not run
#' ## Load example data ##
#' data(wheat_example)
#' ## 5-fold cross validation
#' b <- cvSampleIndex(sampleNum = 2000,cross = 5,seed = 1)
#' 
#' ## End (Not run)

# get sample idx for training and testing
cvSampleIndex <- function( sampleNum, cross = 5, seed = 1,randomSeed = FALSE ) {
  if(randomSeed == TRUE){
    seed <- randomSeed()
  }
  cv <- cross
  resList <- list()
  
  # leave-one-out
  if( cv == sampleNum ){
    vec <- 1:sampleNum
    for( i in 1:sampleNum ){
      resList[[i]] <- list( trainIdx = vec[-i], testIdx = i, cvIdx = i)
    }
  }else {
    #random samples 
    set.seed(seed)
    index <- sample(1:sampleNum, sampleNum, replace = FALSE )
    step = floor( sampleNum/cv )
    
    start <- NULL
    end <- NULL
    train_sampleNums <- rep(0, cv)
    for( i in c(1:cv) ) {
      start <- step*(i-1) + 1
      end <- start + step - 1
      if( i == cv ) 
        end <- sampleNum
      
      testIdx <- index[start:end]
      trainIdx <- index[-c(start:end)]
      resList[[i]] <- list( trainIdx = trainIdx, testIdx = testIdx, cvIdx = i)
    }
  }
  names(resList) <- paste0("cv",1:cross)
  resList
}
