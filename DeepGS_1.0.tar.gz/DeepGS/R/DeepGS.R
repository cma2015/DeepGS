
#' @title Build a genomic selection prediction model using the deep learning technique
#' @description The function applies the deep convolutional neural network to build a prediction model for genomic selection
#' @param trainMat  A genotype matrix(N x M; N individuals,M markers) 
#' @param trainPheno  Vector (N * 1) of phenotype.
#' @param imageSize  (String)this gives a "i * j" image format that the (M x1)markers informations of each individual will be encoded.
#' if the image size exceeds the original snp number, 0 will be polished the lack part,
#' if the image size is less than the original snp number, the last snp(s) will be descaled.
#' @param cnnFrame  A list containing the following element for convolutional neural network (CNN) framework:
#' \itemize{
#'     \item{conv_kernel:} {A vector(K * 1) gives convolutional kernel sizes(width x height) to filter image matrix for K convolutional layers,respectively. }
#'     \item{conv_num_filter:} { A vector(K * 1) gives number of convolutional kernels for K convolutional layers,respectively.}
#'     \item{pool_act_type:} {A vector(K * 1) gives types of active function will define outputs of K convolutional layers which will be an input of corresponding pool layer,
#'     respectively.It include "relu","sigmoid","softrelu" and "tanh". }
#'     \item{pool_type:} {Character, K * 1) types of K pooling layers select from "avg", "max", "sum",respectively.}
#'     \item{pool_kernel:} {(Character, K * 1) K pooling kernel sizes(width x height) for K pooling layers. }
#'     \item{pool_stride:} {(Character, K * 1)strides for K pooling kernels.}
#'     \item{fullayer_num_hidden:} {Numeric, H * 1) number of hidden neurons for H full connected layers, respectively.
#'     the last full connected layer's number of hidden nerurons must is one.  }
#'     \item{fullayer_act_type:} {Numeric, (H-1) * 1) selecting types of active function from "relu", "sigmoid", "softrelu" and "tanh" for full connected layers.}
#' }
#' @param device_type  Selecting "cpu" or "gpu" device to  construct predict model.
#' @param gpuNum  (Integer) number of GPU devices, if using multiple GPU(gpuNum > 1), the parameter momentum must greater than 0.
#' @param eval_metric (String) A approach for evaluating the performance of training process, it include "mae", "rmse" and "accuracy", default "mae".
#' @param num_round (Integer) The number of iterations over training data to train the model,default=10.
#' @param  array_batch_size (Integer) it defines number of samples that going to be propagated through the network for each update weight,default 128.
#' @param learning_rate  The learn rate for training process.
#' @param momentum  (Float,0~1) Momentum for moving average, default 0.9.
#' @param wd (Float,0~1) weight decay,default 0.
#' @param randomseeds  set the seed used by mxnet device-specific random number.
#'  generatiors
#' @param initializer_idx  The initialization scheme for parameters.
#' @param \dots Parameters for construncting neural networks used in package "mxnet"( \url{http://mxnet.io/get_started/setup.html}).
#'  
#' @author Chuang Ma , Zhixu Qiu, Qian Cheng, Wenlong Ma
#' @export
#' @examples 
#' data(wheat_example)
#' Markers <- wheat_example$Markers
#' y <- wheat_example$y
#' cvSampleList <- cvSampleIndex(length(y),10,1)
#' # cross validation set
#' cvIdx <- 1
#' trainIdx <- cvSampleList[[cvIdx]]$trainIdx
#' testIdx <- cvSampleList[[cvIdx]]$testIdx
#' # set DeepGS paramater
#' conv_kernel <- c("4*4","5*5") ## convolution kernels (fileter shape)
#' conv_num_filter <- c(20,28)  ## number of filters
#' pool_act_type <- c("relu","relu") ## active function for next pool
#' pool_type <- c("max","max") ## Max pooling shape
#' pool_kernel <- c("2*2","2*2") ## pooling shape
#' pool_stride <- c("2*2","2*2") ## number of pool kernerls
#' fullayer_num_hidden <- c(56,1)  
#' fullayer_act_type <- c("sigmoid")
#' cnnFrame <- list(conv_kernel =conv_kernel,conv_num_filter = conv_num_filter,
#'                  pool_act_type = pool_act_type,pool_type = pool_type,pool_kernel =pool_kernel,
#'                  pool_stride = pool_stride,fullayer_num_hidden= fullayer_num_hidden,
#'                  fullayer_act_type = fullayer_act_type)
#' 
#' trainGSmodel <- train_GSModel(trainMat = Markers[trainIdx,],trainPheno = y[trainIdx],
#'                             imageSize = "35*35", cnnFrame = cnnFrame,device_type = "cpu",
#'                             gpuNum = 1, eval_metric = "mae", num_round = 30,
#'                             array_batch_size= 100,learning_rate = 0.01,  momentum = 0,
#'                             wd = 0, randomseeds = 0,initializer_idx = 0.01)
#' predscores <- predict_GSModel(GSModel = trainGSmodel,testMat = Markers[testIdx,],
#'                             imageSize = "35*35" )



train_GSModel <- function(trainMat,trainPheno,imageSize,cnnFrame,device_type,gpuNum = "max",eval_metric = "mae",num_round = 10,array_batch_size= 128,learning_rate = 0.01,
                     momentum = 0.9,wd = 0 ,randomseeds = NULL,initializer_idx = 0.01,...){
  requireNamespace("mxnet")
  require(mxnet)
  demo.metric.mae <- mx.metric.custom("mae", function(label, pred) {
    res <- mean(abs(label-pred))
    return(res)
  })
  # this function is used to evluate metrics provide a way to evaluate the performance of a learned model.
  evalfun <- switch(eval_metric,
                    accuracy = mx.metric.accuracy,
                    mae = demo.metric.mae,
                    rmse = mx.metric.rmse)
 # select device type(cpu/gpu) and device number according you computer and task.
  if(device_type == "cpu") { device <- mx.cpu()}
  if(device_type == "gpu") { ifelse(gpuNum == "max", device <- mx.gpu(),device <- lapply(0:(gpuNum -1), function(i) {  mx.gpu(i)}))}
  
  # transform marker matrices into image format
  imageSize <- as.numeric(unlist(strsplit(imageSize,"\\*")))
  trainMat <- t(trainMat)
  if(imageSize[1]*imageSize[2] > nrow(trainMat)){
    trainMat <- rbind(trainMat,matrix(0,imageSize[1]*imageSize[2] - nrow(trainMat),ncol = ncol(trainMat)))
    print("the image size exceeds the original snp number, 0 will be polished the lack part")
  }else if(imageSize[1]*imageSize[2] < nrow(trainMat)){
    trainMat <- trainMat[1:(imageSize[1]*imageSize[2]),] 
    print("the image size is less than the original snp number, the last snp(s) will be descaled")
  }else{
    print("the image size is equal with the original snp number")
  }
  dim(trainMat) <- c(imageSize[1], imageSize[2],1,ncol(trainMat))
  # extract Convolution set from the cnn frame list.
  conv_kernel <- unlist(strsplit(cnnFrame$conv_kernel,"\\*"))
  conv_kernel <- matrix(as.numeric(conv_kernel),ncol = 2,byrow = TRUE)
  conv_num_filter <- cnnFrame$conv_num_filter
  pool_act_type <- cnnFrame$pool_act_type
  pool_type <- cnnFrame$pool_type
  pool_kernel <-  unlist(strsplit(cnnFrame$pool_kernel,"\\*"))
  pool_kernel <- matrix(as.numeric(pool_kernel),ncol = 2,byrow = TRUE)
  pool_stride <-  unlist(strsplit(cnnFrame$pool_stride,"\\*"))
  pool_stride <- matrix(as.numeric(pool_stride),ncol = 2,byrow = TRUE)
  if(nrow(conv_kernel) != length(conv_num_filter) || nrow(conv_kernel)!= length(pool_act_type)){
    stop("Error: a convolutional layer is only matched with one convolution kernel set and one activation." )
  }
  if( nrow(conv_kernel) != nrow(pool_kernel)){
    stop("Error: the number of convolutional layers must equal the number of pooling layers." )
  }
  if(nrow(pool_kernel)!= nrow(pool_stride) || nrow(pool_kernel) != length(pool_type)){
    stop("Error: pooling framwork is inconsistent" )
  }
  # extract full connect set from the cnn frame list.
  fullayer_num_hidden <- cnnFrame$fullayer_num_hidden
  fullayer_act_type <- cnnFrame$fullayer_act_type
  if(length(fullayer_num_hidden) - length(fullayer_act_type) != 1){
    stop("Error: the last full connected layer don't need activation.")
  }
  conv_layer_num <- nrow(conv_kernel)
  fullayer_num <- length(fullayer_num_hidden)
  if(fullayer_num_hidden[fullayer_num] != 1){
    stop("Error: the last full connected layer's number of hidden nerurons must is one.")
  }
  # set Convolution frame
  data <- mx.symbol.Variable('data')
  for(cc in 1:conv_layer_num){
    if(cc == 1){
      assign(paste0("conv",cc),mx.symbol.Convolution(data= data, kernel=conv_kernel[cc,], num_filter= conv_num_filter[cc])) #Convolution layer
    }else if(cc > 1){
      assign(paste0("conv",cc),mx.symbol.Convolution(data= get(paste0("pool",cc-1)), kernel=conv_kernel[cc,], num_filter= conv_num_filter[cc])) #Convolution layer
    } 
    
    assign(paste0("conv_Act",cc), mx.symbol.Activation(data= get(paste0("conv",cc)), act_type= pool_act_type[cc])) ### active function
    assign(paste0("pool",cc),mx.symbol.Pooling(data= get(paste0("conv_Act",cc)), pool_type= pool_type[cc] ,  
                                               kernel= pool_kernel[cc,], stride= pool_stride[cc,])) # pool layer
  }
  # set full connect frame
  fullconnect_initial <- mx.symbol.Flatten(data= get(paste0("pool",conv_layer_num)))
  for(ss in 1:max(c(fullayer_num -1,1))){
    if(ss == 1){
      assign(paste0("fullconnect_layer",ss),mx.symbol.FullyConnected(data= fullconnect_initial, num_hidden= fullayer_num_hidden[ss]))
    } else if(ss > 1){
      assign(paste0("fullconnect_layer",ss),mx.symbol.FullyConnected(data= get(paste0("fullconnect_Act",ss -1)), num_hidden= fullayer_num_hidden[ss]))
      }
    #  performed below when more than more than one full connnect layer
    if(fullayer_num > 1){
      assign(paste0("fullconnect_Act",ss), mx.symbol.Activation(data= get(paste0("fullconnect_layer",ss)), act_type= fullayer_act_type[ss]))
    }
    
  }
  # performed below when more than one full connnect layer
  if(fullayer_num > 1){
    assign(paste0("fullconnect_layer",fullayer_num),mx.symbol.FullyConnected(data= get(paste0("fullconnect_Act",ss)), num_hidden= fullayer_num_hidden[fullayer_num]))
  }
  
  # cnn network
  cnn_nerwork <- mx.symbol.LinearRegressionOutput(data= get(paste0("fullconnect_layer",fullayer_num)))  # mx.symbol.SoftmaxOutput mx.symbol.LogisticRegressionOutput
  
  if(!is.null(randomseeds)){mx.set.seed(randomseeds)}
  cnn.object <- mx.model.FeedForward.create(cnn_nerwork, X=trainMat, y=trainPheno,
                                           ctx= device, num.round= num_round, array.batch.size=array_batch_size,
                                           learning.rate=learning_rate, momentum=momentum, wd=wd,
                                           eval.metric= evalfun,initializer = mx.init.uniform(initializer_idx),
                                           epoch.end.callback=mx.callback.log.train.metric(100))
}

