# NDCGEvaluation <- function( realScores, predScores, topK = 10){
# 
#   if( length(realScores) != length(predScores) ){
#     stop("Error: different length between realScores and predScores")
#   }
#   if( length(realScores) < topK ) {
#     stop("Error: too large topK")
#   }
# 
#   scoreMat <- cbind(realScores,predScores)
#   scoreMatSortbyPred <- scoreMat[order(scoreMat[,2],decreasing = TRUE),]
#   scoreMatSortByReal <- scoreMat[order(scoreMat[,1],decreasing = TRUE),]
# 
#   DCG <- rep(0, topK)
#   IDCG <- rep(0, topK)
#   for(idx in 1:topK){
#     DCG[idx] <-  scoreMatSortbyPred[idx,1]/log(idx+1,2)
#     IDCG[idx] <- scoreMatSortByReal[idx,1]/log(idx+1,2)
#   }
# 
#   NDCG <- sum(DCG)/sum(IDCG)
#   names(NDCG) <- paste0("NDCG","_top",topK)
#   return(NDCG)
# }
# meanNDCG <- function( realScores, predScores, topK = 10 ){
#   topseq <- topK
#   if(length(topK) > 1){
#     topK <- max(topseq)
#   }
#   resVec <- rep(0, topK )
#   for( idx in 1:topK ){
#     resVec[idx] <- NDCGEvaluation( realScores, predScores, topK = idx )
#   }
#   
#   meanNDCG_scores <- sapply(1:length(topseq),function(ii){{
#     mean(resVec[1:topseq[ii]])
#   }})
#   names(meanNDCG_scores) <- paste0("meanNDCG","_top",topseq)
#   return (meanNDCG_scores)
# }
# 

########################################################################
#' @title Calculate mean Normalied Doscounted Cumulative Gain
#' @description  This function calculates the mean normalied doscounted cumulative gain(meanNDCG) value for 
#' evaluting the prediction performance of a genomic selection  prediction model in selecting top k individuals with high breeding value.
#' @param realScores  A numeric vector is the real breeding values of the validation individual for a trait.
#' @param predScores  A numeric vector or matrix is the prediction breeding value predicted by genomic selection model of the individuals.
#' @param topAlpha  A numeric vector (one or mutliple arguments) is the percentage of excellent individuals, default 10.
#' 
#' @author Chuang Ma, Zhixu Qiu, Qian Cheng and Wenlong Ma
#' @export
#' @examples
#' ## Not run
#' refer_value <- runif(100)
#' pred_value <- sin(refer_value) + cos(refer_value)
#' meanNDCG(realScores = refer_value,predScores = pred_value, topAlpha = c(10,20,30))
#' ## End not run
meanNDCG<- function( realScores, predScores, topAlpha = c(10)){
  NDCGEvaluation_new <- function( realScores, predScores, topK = 10){
    if( length(realScores) != length(predScores) ){
      stop("Error: different length between realScores and predScores")
    }
    if( length(realScores) < max(topK) ) {
      stop("Error: too large topK")
    }
    
    scoreMat <- cbind(realScores,predScores)
    scoreMatSortbyPred <- scoreMat[order(scoreMat[,2],decreasing = TRUE),]
    scoreMatSortByReal <- scoreMat[order(scoreMat[,1],decreasing = TRUE),]
    # grade 
    topseq <-  round(topK*length(realScores)/100)
    topK <- max(topseq)
    # calculate
    DCG <- rep(0, topK)
    IDCG <- rep(0, topK)
    for(idx in 1:topK){
      DCG[idx] <-  scoreMatSortbyPred[idx,1]/log(idx+1,2)
      IDCG[idx] <- scoreMatSortByReal[idx,1]/log(idx+1,2)
    }
    NDCGall <- sapply(1:topK,function(kk){
      sum(DCG[1:kk])/sum(IDCG[1:kk])  })
    # output
    NDCG <- NDCGall[topseq]
    names(NDCG) <- paste0("NDCG","_top",topseq)
    meanNDCG <- sapply(topseq,function(kk){mean(NDCGall[1:kk])})
    names(meanNDCG ) <- paste0("meanNDCG","_top",topseq)
    return(list(NDCG =NDCG,meanNDCG =meanNDCG))
  }
  predScores <- as.matrix(predScores)
  mutlieval <- lapply(1:ncol(predScores),function(cc){
    NDCGEvaluation_new(realScores = realScores,predScores = predScores[,cc],topK = topAlpha)
  })
  # NDCG <- matrix(sapply(1:length(mutlieval),function(ii){mutlieval[[ii]]$NDCG}),nrow = length(topAlpha))
  meanNDCG <- matrix(sapply(1:length(mutlieval),function(ii){mutlieval[[ii]]$meanNDCG}),nrow = length(topAlpha))
  # dimnames(NDCG) <- dimnames(meanNDCG) <- list(paste0("top",topAlpha),colnames(predScores))
  # return(list(NDCG =NDCG,meanNDCG =meanNDCG))
  rownames(meanNDCG) <- paste0("top",topAlpha)
  return(meanNDCG)
  
}

